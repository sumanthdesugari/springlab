package com.cg;

public class Employee {
	private int employeId;
	private String employeName;
	private double salary;
	private String businessUnit;
	private int age;
	public int getEmployeId() {
		return employeId;
	}
	public void setEmployeId(int employeId) {
		this.employeId = employeId;
	}
	public String getEmployeName() {
		return employeName;
	}
	public void setEmployeName(String employeName) {
		this.employeName = employeName;
	}
	public double getSalary() {
		return salary;
	}
	public void setSalary(double salary) {
		this.salary = salary;
	}
	public String getBusinessUnit() {
		return businessUnit;
	}
	public void setBusinessUnit(String businessUnit) {
		this.businessUnit = businessUnit;
	}
	public int getAge() {
		return age;
	}
	public void setAge(int age) {
		this.age = age;
	}
	@Override
	public String toString() {
		return "Employee Details employeId=" + employeId + ", employeName="
				+ employeName +", salary=" + salary + ", businessUnit="
				+ businessUnit + ", age=" + age + "";
	}
	

}
