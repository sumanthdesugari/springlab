package com.cg.EmployeeService;

public interface EmployeeService {

}
